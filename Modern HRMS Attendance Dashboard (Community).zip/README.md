
  # Modern HRMS Attendance Dashboard (Community)

  This is a code bundle for Modern HRMS Attendance Dashboard (Community). The original project is available at https://www.figma.com/design/iU0pbqoe3GFqguPlPcVrS5/Modern-HRMS-Attendance-Dashboard--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  