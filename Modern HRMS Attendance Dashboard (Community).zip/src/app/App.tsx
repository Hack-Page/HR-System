import { useState } from 'react';
import { HRMSSidebar } from './components/HRMSSidebar';
import { MonthlyAttendanceReport } from './components/MonthlyAttendanceReport';

export default function App() {
  const [filters, setFilters] = useState<any>({});

  const handleApplyFilters = (newFilters: any) => {
    setFilters(newFilters);
  };

  return (
    <div className="h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex">
      {/* Sidebar */}
      <HRMSSidebar />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Content Area */}
        <main className="flex-1 p-6 overflow-auto">
          <MonthlyAttendanceReport filters={filters} />
        </main>
      </div>
    </div>
  );
}