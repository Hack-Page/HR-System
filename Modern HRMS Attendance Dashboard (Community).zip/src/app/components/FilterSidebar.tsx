import { useState } from 'react';
import { X, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface FilterSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyFilters: (filters: any) => void;
}

export function FilterSidebar({ isOpen, onClose, onApplyFilters }: FilterSidebarProps) {
  const [filters, setFilters] = useState({
    searchEmployee: '',
    date: '07/08/2025',
    site: 'HEAD OFFICE',
    empType: 'All',
    shift: '',
    department: '',
    status: '',
    attendanceStatus: 'Present'
  });

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleApply = () => {
    onApplyFilters(filters);
    onClose();
  };

  const handleCancel = () => {
    setFilters({
      searchEmployee: '',
      date: '07/08/2025',
      site: 'HEAD OFFICE',
      empType: 'All',
      shift: '',
      department: '',
      status: '',
      attendanceStatus: 'Present'
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="fixed inset-0 bg-black/20" onClick={onClose} />
      <div className="ml-auto w-96 bg-white h-full shadow-elevated flex flex-col">
        {/* Simple Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Filter</h2>
          <Button variant="ghost" size="sm" onClick={onClose} className="h-8 w-8 p-0">
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex-1 p-6 space-y-6 overflow-y-auto">
          {/* Search Employee */}
          <div className="space-y-2">
            <Input
              placeholder="Search Employee"
              value={filters.searchEmployee}
              onChange={(e) => handleFilterChange('searchEmployee', e.target.value)}
              className="w-full bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg"
            />
          </div>

          {/* Date */}
          <div className="space-y-2">
            <div className="relative">
              <Input
                type="text"
                value={filters.date}
                onChange={(e) => handleFilterChange('date', e.target.value)}
                className="w-full pr-10 bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg"
                placeholder="07/08/2025"
              />
              <Calendar className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 transform -translate-y-1/2" />
            </div>
          </div>

          {/* Site */}
          <div className="space-y-2">
            <Label className="text-sm text-gray-600">Site</Label>
            <Select value={filters.site} onValueChange={(value) => handleFilterChange('site', value)}>
              <SelectTrigger className="w-full bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="HEAD OFFICE">HEAD OFFICE</SelectItem>
                <SelectItem value="Branch Office 1">Branch Office 1</SelectItem>
                <SelectItem value="Branch Office 2">Branch Office 2</SelectItem>
                <SelectItem value="Remote">Remote</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Emp Type */}
          <div className="space-y-2">
            <Label className="text-sm text-gray-600">Emp Type</Label>
            <Select value={filters.empType} onValueChange={(value) => handleFilterChange('empType', value)}>
              <SelectTrigger className="w-full bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All</SelectItem>
                <SelectItem value="Full Time">Full Time</SelectItem>
                <SelectItem value="Part Time">Part Time</SelectItem>
                <SelectItem value="Contract">Contract</SelectItem>
                <SelectItem value="Intern">Intern</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Shift */}
          <div className="space-y-2">
            <Label className="text-sm text-gray-600">Shift</Label>
            <Select value={filters.shift} onValueChange={(value) => handleFilterChange('shift', value)}>
              <SelectTrigger className="w-full bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg">
                <SelectValue placeholder="Select shift" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="General">General</SelectItem>
                <SelectItem value="Morning">Morning</SelectItem>
                <SelectItem value="Evening">Evening</SelectItem>
                <SelectItem value="Night">Night</SelectItem>
                <SelectItem value="Flexible">Flexible</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Department */}
          <div className="space-y-2">
            <Label className="text-sm text-gray-600">Department</Label>
            <Select value={filters.department} onValueChange={(value) => handleFilterChange('department', value)}>
              <SelectTrigger className="w-full bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg">
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Departments</SelectItem>
                <SelectItem value="FINANCE & ACCOUNTS">Finance & Accounts</SelectItem>
                <SelectItem value="HUMAN RESOURCES">Human Resources</SelectItem>
                <SelectItem value="MANAGEMENT">Management</SelectItem>
                <SelectItem value="IT DEPARTMENT">IT Department</SelectItem>
                <SelectItem value="MARKETING">Marketing</SelectItem>
                <SelectItem value="SALES">Sales</SelectItem>
                <SelectItem value="OPERATIONS">Operations</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Status */}
          <div className="space-y-2">
            <Label className="text-sm text-gray-600">Status</Label>
            <Select value={filters.status} onValueChange={(value) => handleFilterChange('status', value)}>
              <SelectTrigger className="w-full bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Inactive">Inactive</SelectItem>
                <SelectItem value="On Leave">On Leave</SelectItem>
                <SelectItem value="Terminated">Terminated</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Attendance Status */}
          <div className="space-y-2">
            <Label className="text-sm text-gray-600">Attendance Status</Label>
            <Select value={filters.attendanceStatus} onValueChange={(value) => handleFilterChange('attendanceStatus', value)}>
              <SelectTrigger className="w-full bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Present">Present</SelectItem>
                <SelectItem value="Absent">Absent</SelectItem>
                <SelectItem value="Late">Late</SelectItem>
                <SelectItem value="Half Day">Half Day</SelectItem>
                <SelectItem value="Work From Home">Work From Home</SelectItem>
                <SelectItem value="On Leave">On Leave</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Simple Footer */}
        <div className="p-6 border-t border-gray-200 flex gap-3">
          <Button 
            variant="outline" 
            className="flex-1 bg-gray-100 border-gray-300 text-gray-700 hover:bg-gray-200 rounded-lg" 
            onClick={handleCancel}
          >
            CANCEL
          </Button>
          <Button 
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg" 
            onClick={handleApply}
          >
            SUBMIT
          </Button>
        </div>
      </div>
    </div>
  );
}