import { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { MoreHorizontal, ChevronLeft, ChevronRight } from 'lucide-react';

interface AttendanceData {
  [key: string]: 'P' | 'A' | 'L' | 'H' | 'WO' | 'LWP' | 'NA';
}

interface Employee {
  id: string;
  name: string;
  avatar?: string;
  department: string;
  empStatus: string;
  attendance: AttendanceData;
}

const mockEmployees: Employee[] = [
  {
    id: "SHIJIN(E/AAA/227)",
    name: "SHIJIN",
    department: "STORE",
    empStatus: "Active",
    attendance: {
      '1': 'A', '2': 'A', '3': 'A', '4': 'A', '5': 'P', '6': 'P', '7': 'P',
      '8': 'P', '9': 'P', '10': 'P', '11': 'P', '12': 'P', '13': 'P', '14': 'P',
      '15': 'P', '16': 'P', '17': 'P', '18': 'P', '19': 'P', '20': 'P', '21': 'P',
      '22': 'P', '23': 'P', '24': 'P', '25': 'P', '26': 'P', '27': 'P', '28': 'P',
      '29': 'P', '30': 'P', '31': 'P'
    }
  },
  {
    id: "SHIJIN(E.RAJITH/F0006)",
    name: "SHIJIN E.RAJITH",
    department: "PLANNING & BILLING",
    empStatus: "Ex-Employee",
    attendance: {
      '1': 'P', '2': 'P', '3': 'WO', '4': 'P', '5': 'P', '6': 'P', '7': 'P',
      '8': 'P', '9': 'P', '10': 'WO', '11': 'P', '12': 'P', '13': 'P', '14': 'P',
      '15': 'P', '16': 'P', '17': 'WO', '18': 'P', '19': 'P', '20': 'P', '21': 'P',
      '22': 'P', '23': 'P', '24': 'WO', '25': 'P', '26': 'P', '27': 'P', '28': 'P',
      '29': 'P', '30': 'P', '31': 'WO'
    }
  },
  {
    id: "SHIJIN(E.XAMAN/AA/141)",
    name: "SHIJIN E.XAMAN",
    department: "STORE",
    empStatus: "Active",
    attendance: {
      '1': 'P', '2': 'P', '3': 'P', '4': 'P', '5': 'P', '6': 'P', '7': 'P',
      '8': 'P', '9': 'P', '10': 'P', '11': 'P', '12': 'P', '13': 'P', '14': 'P',
      '15': 'P', '16': 'P', '17': 'P', '18': 'P', '19': 'P', '20': 'P', '21': 'P',
      '22': 'P', '23': 'P', '24': 'P', '25': 'P', '26': 'P', '27': 'P', '28': 'P',
      '29': 'P', '30': 'P', '31': 'P'
    }
  },
  {
    id: "SHIJIN(E.RAJITH/F0070)",
    name: "SHIJIN E.RAJITH",
    department: "PLANNING & BILLING",
    empStatus: "Ex-Employee",
    attendance: {
      '1': 'NA', '2': 'NA', '3': 'NA', '4': 'NA', '5': 'NA', '6': 'NA', '7': 'NA',
      '8': 'NA', '9': 'NA', '10': 'NA', '11': 'NA', '12': 'NA', '13': 'NA', '14': 'NA',
      '15': 'NA', '16': 'NA', '17': 'NA', '18': 'NA', '19': 'NA', '20': 'NA', '21': 'NA',
      '22': 'NA', '23': 'NA', '24': 'NA', '25': 'NA', '26': 'NA', '27': 'NA', '28': 'NA',
      '29': 'NA', '30': 'NA', '31': 'NA'
    }
  },
  {
    id: "SHIJIN(E.RAJITH/F0080)",
    name: "SHIJIN E.RAJITH",
    department: "PLANNING & BILLING",
    empStatus: "Ex-Employee",
    attendance: {
      '1': 'NA', '2': 'NA', '3': 'NA', '4': 'NA', '5': 'NA', '6': 'NA', '7': 'NA',
      '8': 'NA', '9': 'NA', '10': 'NA', '11': 'NA', '12': 'NA', '13': 'NA', '14': 'NA',
      '15': 'NA', '16': 'NA', '17': 'NA', '18': 'NA', '19': 'NA', '20': 'NA', '21': 'NA',
      '22': 'NA', '23': 'NA', '24': 'NA', '25': 'NA', '26': 'NA', '27': 'NA', '28': 'NA',
      '29': 'NA', '30': 'NA', '31': 'NA'
    }
  },
  {
    id: "SHIJIN(E.G.DILLIRAP)",
    name: "SHIJIN G.DILLIRAP",
    department: "ADMIN",
    empStatus: "Active",
    attendance: {
      '1': 'P', '2': 'P', '3': 'WO', '4': 'P', '5': 'P', '6': 'P', '7': 'P',
      '8': 'P', '9': 'P', '10': 'WO', '11': 'P', '12': 'P', '13': 'P', '14': 'P',
      '15': 'P', '16': 'P', '17': 'WO', '18': 'P', '19': 'P', '20': 'P', '21': 'P',
      '22': 'P', '23': 'P', '24': 'WO', '25': 'P', '26': 'P', '27': 'P', '28': 'P',
      '29': 'P', '30': 'P', '31': 'WO'
    }
  }
];

const getDaysInMonth = () => {
  // August 2024 - returning array of day numbers and day names
  const days = [];
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const firstDay = new Date(2024, 7, 1); // August 1, 2024
  
  for (let i = 1; i <= 31; i++) {
    const date = new Date(2024, 7, i);
    const dayName = daysOfWeek[date.getDay()];
    days.push({ day: i, dayName: dayName.slice(0, 3) });
  }
  return days;
};

interface MonthlyAttendanceTableProps {
  filters?: any;
}

export function MonthlyAttendanceTable({ filters }: MonthlyAttendanceTableProps) {
  const [employees] = useState<Employee[]>(mockEmployees);
  const [currentPage, setCurrentPage] = useState(1);
  const days = getDaysInMonth();

  const getAttendanceBadge = (status: string) => {
    const statusConfig = {
      'P': { 
        className: 'bg-emerald-100 text-emerald-800 border-emerald-200 hover:bg-emerald-200 transition-colors',
        label: 'P'
      },
      'A': { 
        className: 'bg-red-100 text-red-800 border-red-200 hover:bg-red-200 transition-colors',
        label: 'A'
      },
      'L': { 
        className: 'bg-orange-100 text-orange-800 border-orange-200 hover:bg-orange-200 transition-colors',
        label: 'L'
      },
      'H': { 
        className: 'bg-blue-100 text-blue-800 border-blue-200 hover:bg-blue-200 transition-colors',
        label: 'H'
      },
      'WO': { 
        className: 'bg-purple-100 text-purple-800 border-purple-200 hover:bg-purple-200 transition-colors',
        label: 'WO'
      },
      'LWP': { 
        className: 'bg-yellow-100 text-yellow-800 border-yellow-200 hover:bg-yellow-200 transition-colors',
        label: 'LWP'
      },
      'NA': { 
        className: 'bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200 transition-colors',
        label: 'NA'
      }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig['NA'];
    return (
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-semibold cursor-pointer ${config.className}`}>
        {config.label}
      </div>
    );
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const getDepartmentColor = (department: string) => {
    const colors = {
      'STORE': 'bg-gradient-to-r from-blue-500 to-blue-600',
      'PLANNING & BILLING': 'bg-gradient-to-r from-purple-500 to-purple-600', 
      'ADMIN': 'bg-gradient-to-r from-emerald-500 to-green-600',
      'IT DEPARTMENT': 'bg-gradient-to-r from-indigo-500 to-indigo-600'
    };
    return colors[department as keyof typeof colors] || 'bg-gradient-to-r from-gray-400 to-gray-500';
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-card">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gradient-to-r from-slate-50 to-blue-50/50 border-b border-blue-100">
              <TableHead className="w-12 text-center font-semibold text-gray-700 sticky left-0 bg-gradient-to-r from-slate-50 to-blue-50/50">#</TableHead>
              <TableHead className="min-w-[200px] font-semibold text-gray-700 sticky left-12 bg-gradient-to-r from-slate-50 to-blue-50/50">Employee</TableHead>
              <TableHead className="min-w-[120px] font-semibold text-gray-700 sticky left-[252px] bg-gradient-to-r from-slate-50 to-blue-50/50">Department</TableHead>
              <TableHead className="min-w-[100px] font-semibold text-gray-700 sticky left-[372px] bg-gradient-to-r from-slate-50 to-blue-50/50">Emp Status</TableHead>
              {days.map((day) => (
                <TableHead key={day.day} className="w-12 text-center font-semibold text-gray-700">
                  <div className="flex flex-col items-center gap-1">
                    <span className="text-xs font-bold">{day.day}</span>
                    <span className="text-xs text-gray-500">{day.dayName}</span>
                  </div>
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {employees.map((employee, index) => (
              <TableRow key={employee.id} className="hover:bg-blue-50/30 border-b border-gray-100 transition-colors">
                <TableCell className="text-center sticky left-0 bg-white border-r border-gray-100">
                  <div className="w-8 h-8 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center">
                    <span className="text-xs font-semibold text-gray-600">{index + 1}</span>
                  </div>
                </TableCell>
                <TableCell className="sticky left-12 bg-white border-r border-gray-100">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-9 h-9 ring-2 ring-white shadow-sm">
                      <AvatarImage src={employee.avatar} />
                      <AvatarFallback className={`${getDepartmentColor(employee.department)} text-white text-xs font-semibold`}>
                        {getInitials(employee.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-semibold text-gray-800 text-sm">{employee.name}</div>
                      <div className="text-xs text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded inline-block mt-0.5">{employee.id}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="sticky left-[252px] bg-white border-r border-gray-100">
                  <span className="inline-block bg-gradient-to-r from-gray-50 to-gray-100 text-gray-700 px-2.5 py-1 rounded-lg text-sm font-medium border border-gray-200">
                    {employee.department}
                  </span>
                </TableCell>
                <TableCell className="sticky left-[372px] bg-white border-r border-gray-100">
                  <Badge className={employee.empStatus === 'Active' 
                    ? 'bg-emerald-100 text-emerald-700 border-emerald-200' 
                    : 'bg-gray-100 text-gray-600 border-gray-200'
                  }>
                    {employee.empStatus}
                  </Badge>
                </TableCell>
                {days.map((day) => (
                  <TableCell key={day.day} className="text-center p-2">
                    {getAttendanceBadge(employee.attendance[day.day.toString()])}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200 bg-gray-50">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <span>Showing 1-6 of 50 employees</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" disabled className="w-8 h-8 p-0">
            <ChevronLeft className="w-4 h-4" />
          </Button>
          {[1, 2, 3, 4, 5].map((page) => (
            <Button
              key={page}
              variant={currentPage === page ? "default" : "outline"}
              size="sm"
              className="w-8 h-8 p-0"
              onClick={() => setCurrentPage(page)}
            >
              {page}
            </Button>
          ))}
          <span className="text-gray-500">...</span>
          <Button variant="outline" size="sm" className="w-8 h-8 p-0">15</Button>
          <Button variant="outline" size="sm" className="w-8 h-8 p-0">
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}