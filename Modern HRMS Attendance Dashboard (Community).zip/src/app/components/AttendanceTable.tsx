import { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { MoreHorizontal, CheckCircle2, XCircle, Clock, AlertTriangle } from 'lucide-react';

interface Employee {
  id: string;
  name: string;
  avatar?: string;
  shift: string;
  department: string;
  workType: string;
  location: string;
  status: 'CheckedOut' | 'CheckedIn' | 'Absent' | 'Late';
  checkIn: string;
  date: string;
}

const mockEmployees: Employee[] = [
  {
    id: "ROHIT GUPTA(PG001)",
    name: "ROHIT GUPTA",
    shift: "General",
    department: "FINANCE & ACCOUNTS",
    workType: "OFFICE",
    location: "OFFICE",
    status: "CheckedOut",
    checkIn: "09:30",
    date: "01/08/2025"
  },
  {
    id: "ANILKUMAR CHTRKAR(ACC011)",
    name: "ANILKUMAR CHTRKAR",
    shift: "General",
    department: "HUMAN RESOURCES",
    workType: "OFFICE",
    location: "OFFICE",
    status: "CheckedIn",
    checkIn: "09:15",
    date: "01/08/2025"
  },
  {
    id: "SUSHIL KUMAR(ESQ)",
    name: "SUSHIL KUMAR",
    shift: "General",
    department: "HUMAN RESOURCES",
    workType: "OFFICE",
    location: "OFFICE",
    status: "Late",
    checkIn: "10:15",
    date: "01/08/2025"
  },
  {
    id: "PREM PRAKASH PATITAK(PPT)",
    name: "PREM PRAKASH PATITAK",
    shift: "General",
    department: "IT DEPARTMENT",
    workType: "OFFICE",
    location: "OFFICE",
    status: "CheckedOut",
    checkIn: "09:00",
    date: "01/08/2025"
  },
  {
    id: "SUNIDYA CSHIKARN(SG019)",
    name: "SUNIDYA CSHIKARN",
    shift: "General",
    department: "MANAGEMENT",
    workType: "OFFICE",
    location: "OFFICE",
    status: "Absent",
    checkIn: "--",
    date: "01/08/2025"
  }
];

interface AttendanceTableProps {
  filters?: any;
}

export function AttendanceTable({ filters }: AttendanceTableProps) {
  const [employees] = useState<Employee[]>(mockEmployees);

  const getStatusBadge = (status: Employee['status']) => {
    const statusConfig = {
      CheckedOut: { 
        label: 'Checked Out', 
        icon: <CheckCircle2 className="w-3 h-3" />,
        className: 'bg-gradient-to-r from-emerald-50 to-green-100 text-emerald-700 border-emerald-200 shadow-sm' 
      },
      CheckedIn: { 
        label: 'Checked In', 
        icon: <CheckCircle2 className="w-3 h-3" />,
        className: 'bg-gradient-to-r from-blue-50 to-indigo-100 text-blue-700 border-blue-200 shadow-sm' 
      },
      Absent: { 
        label: 'Absent', 
        icon: <XCircle className="w-3 h-3" />,
        className: 'bg-gradient-to-r from-red-50 to-rose-100 text-red-700 border-red-200 shadow-sm' 
      },
      Late: { 
        label: 'Late', 
        icon: <AlertTriangle className="w-3 h-3" />,
        className: 'bg-gradient-to-r from-amber-50 to-orange-100 text-orange-700 border-orange-200 shadow-sm' 
      }
    };

    const config = statusConfig[status];
    return (
      <Badge className={`${config.className} gap-1 px-3 py-1`}>
        {config.icon}
        {config.label}
      </Badge>
    );
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const getDepartmentColor = (department: string) => {
    const colors = {
      'FINANCE & ACCOUNTS': 'bg-gradient-to-r from-blue-500 to-blue-600',
      'HUMAN RESOURCES': 'bg-gradient-to-r from-purple-500 to-purple-600', 
      'MANAGEMENT': 'bg-gradient-to-r from-indigo-500 to-indigo-600',
      'IT DEPARTMENT': 'bg-gradient-to-r from-emerald-500 to-green-600',
      'NA': 'bg-gradient-to-r from-gray-400 to-gray-500'
    };
    return colors[department as keyof typeof colors] || 'bg-gradient-to-r from-gray-400 to-gray-500';
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-2xl border border-blue-100/50 overflow-hidden shadow-card">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gradient-to-r from-slate-50 to-blue-50/50 border-b border-blue-100/50">
              <TableHead className="w-12 text-center font-semibold text-gray-700">#</TableHead>
              <TableHead className="min-w-[220px] font-semibold text-gray-700">Employee</TableHead>
              <TableHead className="font-semibold text-gray-700">Shift</TableHead>
              <TableHead className="font-semibold text-gray-700">Department</TableHead>
              <TableHead className="font-semibold text-gray-700">Work Type</TableHead>
              <TableHead className="font-semibold text-gray-700">Location</TableHead>
              <TableHead className="font-semibold text-gray-700">Status</TableHead>
              <TableHead className="font-semibold text-gray-700">Check In</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {employees.map((employee, index) => (
              <TableRow key={employee.id} className="hover:bg-gradient-to-r hover:from-blue-50/50 hover:to-indigo-50/30 border-b border-gray-100/50 transition-all duration-200">
                <TableCell className="text-center">
                  <div className="w-8 h-8 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center">
                    <span className="text-xs font-semibold text-gray-600">{index + 1}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-4">
                    <Avatar className="w-10 h-10 ring-2 ring-white shadow-card">
                      <AvatarImage src={employee.avatar} />
                      <AvatarFallback className={`${getDepartmentColor(employee.department)} text-white text-sm font-semibold`}>
                        {getInitials(employee.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-semibold text-gray-800">{employee.name}</div>
                      <div className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-md inline-block mt-1">{employee.id}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-500" />
                    <span className="text-gray-700 font-medium">{employee.shift}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="inline-block bg-gradient-to-r from-gray-50 to-gray-100 text-gray-700 px-3 py-1.5 rounded-lg text-sm font-medium border border-gray-200">
                    {employee.department}
                  </span>
                </TableCell>
                <TableCell>
                  <span className="text-gray-700 font-medium">{employee.workType}</span>
                </TableCell>
                <TableCell>
                  <span className="text-gray-700 font-medium">{employee.location}</span>
                </TableCell>
                <TableCell>{getStatusBadge(employee.status)}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="font-semibold text-gray-800">{employee.checkIn}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Button variant="ghost" size="sm" className="h-9 w-9 p-0 hover:bg-gradient-to-br hover:from-gray-100 hover:to-gray-200 rounded-lg">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}