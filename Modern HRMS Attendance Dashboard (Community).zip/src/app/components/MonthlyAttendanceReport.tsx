import { useState } from 'react';
import { Calendar, Download, Upload, FileText, ChevronDown, Filter } from 'lucide-react';
import { MonthlyAttendanceTable } from './MonthlyAttendanceTable';
import { FilterSidebar } from './FilterSidebar';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface MonthlyAttendanceReportProps {
  filters?: any;
}

export function MonthlyAttendanceReport({ filters }: MonthlyAttendanceReportProps) {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState('august-2024');
  const [activeTab, setActiveTab] = useState('detail');

  const handleApplyFilters = (newFilters: any) => {
    // Handle filter application
  };

  const statusLegend = [
    { key: 'P', label: 'Present', color: 'bg-emerald-500', textColor: 'text-emerald-700' },
    { key: 'A', label: 'Absent', color: 'bg-red-500', textColor: 'text-red-700' },
    { key: 'L', label: 'Late', color: 'bg-orange-500', textColor: 'text-orange-700' },
    { key: 'H', label: 'Holiday', color: 'bg-blue-500', textColor: 'text-blue-700' },
    { key: 'WO', label: 'Week Off', color: 'bg-purple-500', textColor: 'text-purple-700' },
    { key: 'LWP', label: 'LWP', color: 'bg-yellow-500', textColor: 'text-yellow-700' },
    { key: 'NA', label: 'Not Applicable', color: 'bg-gray-500', textColor: 'text-gray-600' },
    { key: 'HR', label: 'Half Day', color: 'bg-indigo-500', textColor: 'text-indigo-700' },
    { key: 'OD', label: 'On Duty', color: 'bg-teal-500', textColor: 'text-teal-700' },
    { key: 'CL', label: 'Casual Leave', color: 'bg-pink-500', textColor: 'text-pink-700' },
    { key: 'SL', label: 'Sick Leave', color: 'bg-rose-500', textColor: 'text-rose-700' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-card">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-card">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-gray-800">Monthly Attendance Report</h1>
              <p className="text-sm text-gray-600">Comprehensive monthly attendance tracking and analysis</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="w-44 bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500/20 rounded-lg">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="august-2024">August 2024</SelectItem>
                <SelectItem value="july-2024">July 2024</SelectItem>
                <SelectItem value="june-2024">June 2024</SelectItem>
                <SelectItem value="may-2024">May 2024</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Tabs and Action Buttons */}
        <div className="flex items-center justify-between">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-auto">
            <TabsList className="bg-gray-100 p-1 rounded-lg">
              <TabsTrigger value="summary" className="px-4 py-2 rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm">
                Summary
              </TabsTrigger>
              <TabsTrigger value="detail" className="px-4 py-2 rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm">
                Detail
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex items-center gap-3">
            <Button 
              variant="outline"
              className="gap-2 border-gray-300 hover:bg-gray-50"
              onClick={() => setIsFilterOpen(true)}
            >
              <Filter className="w-4 h-4" />
              Filter
            </Button>
            <Button variant="outline" className="gap-2 border-blue-300 text-blue-700 hover:bg-blue-50">
              <Download className="w-4 h-4" />
              Attendance Export
            </Button>
            <Button variant="outline" className="gap-2 border-green-300 text-green-700 hover:bg-green-50">
              <Upload className="w-4 h-4" />
              Import
            </Button>
            <Button variant="outline" className="gap-2 border-purple-300 text-purple-700 hover:bg-purple-50">
              <FileText className="w-4 h-4" />
              Template
            </Button>
          </div>
        </div>
      </div>

      {/* Summary/Detail Content */}
      <Tabs value={activeTab} className="space-y-6">
        <TabsContent value="summary" className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-card">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Summary View</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-gradient-to-br from-emerald-50 to-green-100 p-4 rounded-xl border border-emerald-200">
                <div className="text-emerald-700 font-semibold">Total Present</div>
                <div className="text-2xl font-bold text-emerald-800">1,847</div>
                <div className="text-sm text-emerald-600">86.4% of total days</div>
              </div>
              <div className="bg-gradient-to-br from-red-50 to-rose-100 p-4 rounded-xl border border-red-200">
                <div className="text-red-700 font-semibold">Total Absent</div>
                <div className="text-2xl font-bold text-red-800">124</div>
                <div className="text-sm text-red-600">5.8% of total days</div>
              </div>
              <div className="bg-gradient-to-br from-orange-50 to-amber-100 p-4 rounded-xl border border-orange-200">
                <div className="text-orange-700 font-semibold">Late Arrivals</div>
                <div className="text-2xl font-bold text-orange-800">67</div>
                <div className="text-sm text-orange-600">3.1% of total days</div>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-4 rounded-xl border border-blue-200">
                <div className="text-blue-700 font-semibold">Holidays</div>
                <div className="text-2xl font-bold text-blue-800">98</div>
                <div className="text-sm text-blue-600">4.6% of total days</div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="detail" className="space-y-6">
          <MonthlyAttendanceTable filters={filters} />
        </TabsContent>
      </Tabs>

      {/* Status Legend */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-card">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Attendance Status Legend</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {statusLegend.map((status) => (
            <div key={status.key} className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50 transition-colors">
              <div className={`w-4 h-4 rounded ${status.color}`}></div>
              <div className="flex items-center gap-1">
                <span className="font-semibold text-gray-700 text-sm">{status.key}</span>
                <span className={`text-sm ${status.textColor}`}>{status.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Filter Sidebar */}
      <FilterSidebar
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
        onApplyFilters={handleApplyFilters}
      />
    </div>
  );
}