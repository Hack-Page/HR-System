import { useState } from 'react';
import { 
  Calendar, 
  Users, 
  Clock, 
  BarChart3, 
  UserCheck, 
  Settings, 
  Wallet, 
  FileText, 
  PlusCircle,
  ChevronDown,
  ChevronRight,
  Building2
} from 'lucide-react';
import { Button } from './ui/button';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  isActive?: boolean;
  hasSubmenu?: boolean;
  isExpanded?: boolean;
  onClick?: () => void;
}

function SidebarItem({ icon, label, isActive, hasSubmenu, isExpanded, onClick }: SidebarItemProps) {
  return (
    <Button
      variant="ghost"
      className={`w-full justify-start gap-3 px-4 py-3 h-auto rounded-xl transition-all duration-200 ${
        isActive 
          ? 'bg-white/20 text-white shadow-soft backdrop-blur-sm border border-white/30' 
          : 'text-white/80 hover:bg-white/10 hover:text-white hover:shadow-soft'
      }`}
      onClick={onClick}
    >
      <span className="w-5 h-5">{icon}</span>
      <span className="flex-1 text-left font-medium">{label}</span>
      {hasSubmenu && (
        <span className="w-4 h-4 transition-transform duration-200">
          {isExpanded ? <ChevronDown /> : <ChevronRight />}
        </span>
      )}
    </Button>
  );
}

export function HRMSSidebar() {
  const [expandedItems, setExpandedItems] = useState<string[]>(['attendance']);

  const toggleExpanded = (item: string) => {
    setExpandedItems(prev => 
      prev.includes(item) 
        ? prev.filter(i => i !== item)
        : [...prev, item]
    );
  };

  return (
    <div className="w-72 bg-gradient-to-b from-indigo-600 via-blue-600 to-purple-700 h-full flex flex-col shadow-elevated">
      {/* Enhanced Header */}
      <div className="p-6 border-b border-white/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm border border-white/30">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">HRMS</h1>
            <p className="text-xs text-blue-100">Human Resource Management</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <SidebarItem
          icon={<BarChart3 />}
          label="Dashboard"
          onClick={() => {}}
        />
        
        <div className="pt-2">
          <SidebarItem
            icon={<Users />}
            label="Attendance List"
            hasSubmenu
            isExpanded={expandedItems.includes('attendance')}
            onClick={() => toggleExpanded('attendance')}
          />
          
          {expandedItems.includes('attendance') && (
            <div className="ml-6 mt-2 space-y-1 pl-4 border-l border-white/20">
              <SidebarItem
                icon={<Clock />}
                label="Daily Attendance"
              />
              <SidebarItem
                icon={<Calendar />}
                label="Monthly Attendance"
                isActive
              />
              <SidebarItem
                icon={<UserCheck />}
                label="Att. Regularization"
              />
            </div>
          )}
        </div>
        
        <SidebarItem
          icon={<Settings />}
          label="Attendance Setup"
          hasSubmenu
          isExpanded={expandedItems.includes('setup')}
          onClick={() => toggleExpanded('setup')}
        />
        
        <SidebarItem
          icon={<FileText />}
          label="Leave"
          hasSubmenu
          isExpanded={expandedItems.includes('leave')}
          onClick={() => toggleExpanded('leave')}
        />
        
        <SidebarItem
          icon={<Settings />}
          label="Leave Setup"
          hasSubmenu
        />
        
        <SidebarItem
          icon={<Calendar />}
          label="Week Off"
        />
        
        <SidebarItem
          icon={<PlusCircle />}
          label="OD Application"
        />
        
        <SidebarItem
          icon={<Wallet />}
          label="Reimbursement"
          hasSubmenu
        />
        
        <SidebarItem
          icon={<Settings />}
          label="Reimbursement Setup"
          hasSubmenu
        />
        
        <SidebarItem
          icon={<Wallet />}
          label="Payroll"
          hasSubmenu
        />
        
        <SidebarItem
          icon={<Settings />}
          label="Payroll Setup"
          hasSubmenu
        />
      </nav>
      
      {/* Footer */}
      <div className="p-4 border-t border-white/20">
        <div className="bg-white/10 rounded-xl p-3 backdrop-blur-sm border border-white/20">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-lg"></div>
            <div className="flex-1">
              <p className="text-sm font-medium text-white">System Status</p>
              <p className="text-xs text-blue-100">All systems operational</p>
            </div>
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>
    </div>
  );
}